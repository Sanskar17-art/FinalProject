<?php
session_start();

// Ensure user is logged in
if (!isset($_SESSION['user_email'])) {
    // Redirect to login if session is not set
    header('Location: User_Login.php');
    exit();
}

// Include the header
include('Navbar.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Home</title>
    <link rel="stylesheet" href="CSS/Report.css">
</head>
<body>
    <div class="home-section">
        <h2>Welcome to the User Home Page</h2>
        <p>Explore the features of this platform using the navigation menu.</p>
    </div>
</body>
</html>
