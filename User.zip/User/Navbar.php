<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navigation Bar</title>
    <link rel="stylesheet" href="Navbar.css">
</head>
<body>

    <div class="navbar">
        <h1 class="title">WHAT YOU WANT</h1>
        <ul>
            <li><a href="User_Home.php">Home</a></li>
            <li><a href="Profile.php">Profile</a></li>
            <li><a href="Contact.php">Contact</a></li>
            <li><a href="Report.php">Report</a></li>
            <li><a href="About_us.php">About</a></li>
        </ul>
        <!-- Profile Icon (Hidden by default) -->
        <div class="profile-container">
            <img src="profile-icon.png" alt="Profile" class="profile-icon">
        </div>
    </div>

</body>
</html>
